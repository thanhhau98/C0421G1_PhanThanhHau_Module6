drop database if exists manager_school;   
create database manager_school;
use manager_school;

create table division(
division_id int primary key not null auto_increment,
division_name varchar (50) not null
);
create table degree(
degree_id int primary key not null auto_increment,
degree_name varchar (50) not null
);

create table teacher(
teacher_id int primary key not null auto_increment ,
teacher_name varchar(50) not null,
teacher_gender boolean not null,
teacher_dOB varchar(50) not null,
teacher_university varchar(250) not null,
teacher_address varchar(250) not null,
teacher_email varchar(50) not null,
teacher_phone varchar(50) not null,
teacher_image varchar(5000) not null,
teacher_division_id int not null,
teacher_degree_id int not null,
account_id int not null,
    delete_flag bit,
foreign key (teacher_degree_id) references degree(degree_id) on update cascade on delete cascade,
foreign key (teacher_division_id) references division(division_id) on update cascade on delete cascade

);

create table `account`(
id_account int primary key auto_increment,
username varchar(50) ,
`password` varchar(255),
is_actived bit,
is_not_lock bit,
is_delete bit,
teacher_id int,
foreign key (teacher_id ) references `teacher`(teacher_id) on update cascade on delete cascade
);

create table `role`(
id_role int primary key auto_increment,
name_role varchar(50));
create table account_role(
id int primary key auto_increment,
account_id int,
role_id int,
foreign key (account_id) references `account`(id_account) on update cascade on delete cascade,
foreign key (role_id) references `role`(id_role) on update cascade on delete cascade
);




create table grade(
	id_grade int auto_increment primary key,
    `name` varchar(15)
	
);
create table class_grade(
	id_class_grade int auto_increment primary key,
    `name` varchar(15),
    school_year varchar(255),
    grade_id int,
    teacher_id int,
    student_id int not null,
        delete_flag bit,
    foreign key (grade_id) references grade(id_grade) on update cascade on delete cascade,
	foreign key ( teacher_id) references teacher(teacher_id) on update cascade on delete cascade
    
);
CREATE TABLE student(
	id_student INT PRIMARY KEY AUTO_INCREMENT,
    gender DOUBLE,
    father_name VARCHAR(45),
    mother_name VARCHAR(45),
    date_of_birth DATE,
    ethnicity VARCHAR(45),
    address VARCHAR(45),
    `name` VARCHAR(45),
    religion VARCHAR(45),
    image VARCHAR(45),
    `status` VARCHAR(45),
    parent_phone VARCHAR(45),
    class_id int not null,
    delete_flag bit,
    foreign key (class_id) references `class_grade`(id_class_grade) on update cascade on delete cascade
);

create table `subject` (id_subject int primary key AUTO_INCREMENT not null,
						`name` varchar(255));
                        

 create table study_day_time (id_study_day_time INT PRIMARY key AUTO_INCREMENT not null,
							study_time VARCHAR(255) not null,
                            study_day VARCHAR(255) not null,
							UNIQUE KEY study_day_time (study_time, study_day)
                        );      
                        
--  o day nhom nao tao class thi moi tao class id code duoi day la test
create table `schedule` (id_schedule INT PRIMARY key AUTO_INCREMENT not null,
						id_class int not null,
                         foreign key (id_class) references `class_grade`(id_class_grade) on update cascade on delete cascade
                        );                        
                        
create table schedule_detail (
 id_schedule_detail INT PRIMARY key AUTO_INCREMENT not null,
 id_subject int ,
 id_study_day_time int,
 id_schedule int,
 id_class int,
 FOREIGN KEY (id_subject) REFERENCES `subject` (id_subject),
 FOREIGN KEY (id_study_day_time) REFERENCES study_day_time (id_study_day_time),
 FOREIGN KEY (id_schedule) REFERENCES `schedule` (id_schedule)
 -- foreign key (id_class) references `class_grade`(id_class_grade) on update cascade on delete cascade
 );
 
 CREATE TABLE mark (
    id_mark INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
	id_student INT NOT NULL,
    id_subject INT NOT NULL,
    point_number1 DOUBLE,
    point_number2 DOUBLE,
    point_number3 DOUBLE,
    
foreign key (id_student) references student(id_student) on update cascade on delete cascade,
foreign key (id_subject) references `subject`(id_subject) on update cascade on delete cascade
);

